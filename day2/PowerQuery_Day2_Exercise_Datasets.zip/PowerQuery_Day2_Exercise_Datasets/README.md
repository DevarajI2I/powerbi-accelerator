# Power Query & Data Connectivity — Synthetic Exercise Dataset

All data is synthetic and intended for training only.

## Set 1 — Retail
Focus: CSV connectivity, data types, cleaning, nulls, duplicates, text/date cleanup, merge, calculated columns and basic M.
Intentional issues: missing Customer_ID, null Discount, negative Quantity, inconsistent Sales_Channel, dates as text.

## Set 2 — Healthcare
Focus: Append, Merge, exception queries, missing keys, standardization and reusable M transformations.
Intentional issues: unmatched member/provider IDs, duplicate Claim_ID values, missing Paid_Amount, inconsistent Claim_Status, missing Diagnosis_Category.
Healthcare data is synthetic and does not represent Optum confidential data.

## Set 3 — Supply Chain
Sources: ERP_PurchaseOrders.csv, WMS_Inventory.csv, TMS_Shipments.csv, Supplier_Master.xlsx, Warehouse_Master.csv, Product_Master.csv.
Focus: multi-source connectivity, staging, merge/append, reusable transformations, custom M functions and refreshability.
Monthly PO files: PO_2026_01.csv, PO_2026_02.csv, PO_2026_03.csv.

Recommended pattern: Source → Staging → Transform → Validate → Final Query → Load.
