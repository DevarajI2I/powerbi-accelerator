# Power BI Days 3–5 — Separate Domain Datasets

There are NINE independent datasets: 3 days × 3 business domains.

Retail/
  Day3_Semantic_Modeling/
  Day4_Visualization_UX/
  Day5_DAX/

Healthcare/
  Day3_Semantic_Modeling/
  Day4_Visualization_UX/
  Day5_DAX/

SupplyChain/
  Day3_Semantic_Modeling/
  Day4_Visualization_UX/
  Day5_DAX/

All data is synthetic. Healthcare data does not represent Optum confidential/internal data.
